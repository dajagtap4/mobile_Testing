package org.deepakjagtap;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.Duration;

import org.deepakjagtap.pages.FormPage;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.google.common.collect.ImmutableBiMap;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class BaseTest {
	AppiumDriverLocalService service;
	AndroidDriver driver;
	FormPage formPage;

//	@BeforeSuite
//	public void ConfigureAppium() throws MalformedURLException, URISyntaxException, InterruptedException {
//		service = new AppiumServiceBuilder()
//				.withAppiumJS(new File(
//						"C://Users//Administrator//AppData//Roaming//npm//node_modules//appium//build//lib//main.js"))
//				.withIPAddress("127.0.0.1").usingPort(4723).build();
//
//		service.start();
//
//		System.out.println("******************************************");
//		System.out.println("Appium Server Started:" + service.isRunning());
//		System.out.println("******************************************");
//
//		int retryCount = 0;
//		while (!service.isRunning() && retryCount < 10) {
//			System.out.println("Waiting for Appium server to start...");
//			Thread.sleep(1000);
//			retryCount++;
//		}
//	}

	@BeforeMethod
	public void driverInstance() throws MalformedURLException, URISyntaxException {
		UiAutomator2Options options = new UiAutomator2Options();
		options.setDeviceName("Pixel 3a");
		options.setApp("C://Users//Deepak//eclipse-workspace//Appium_Android_Framework_POM//src//test//java//resources//General-Store.apk");
		driver = new AndroidDriver(new URI("http://127.0.0.1:4723/").toURL(), options);
		formPage = new FormPage(driver);

		if (driver == null) {
			System.out.println("Driver initialization failed.");
			Assert.fail("Driver initialization failed.");
		}

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

	@AfterSuite
	public void tearDownServer() {
		if (service != null) {
		    service.stop();
		}
		System.out.println("******************************************");
		System.out.println("Appium Server Stopped....");
		System.out.println("******************************************");
	}

	public void longPressAction(WebElement ele) {
		((JavascriptExecutor) driver).executeScript("mobile:longClickGesture",
				ImmutableBiMap.of("elementId", ((RemoteWebElement) ele).getId(), "duration", 2000));
	}

}
