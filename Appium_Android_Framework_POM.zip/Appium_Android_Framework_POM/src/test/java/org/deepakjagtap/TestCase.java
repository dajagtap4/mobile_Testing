package org.deepakjagtap;

import org.deepakjagtap.pages.CartPage;
import org.deepakjagtap.pages.ProductCatalogue;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestCase extends BaseTest {
	@Test
	public void verifyUserCanFillForm() {
		formPage.setNameField("Deepak QA");
		formPage.setGender("female");
		formPage.setCountrySelection("Antarctica");

		ProductCatalogue productCatalogue = formPage.submitForm();
		String actualProductTitle = productCatalogue.getProductTitle();
		Assert.assertEquals(actualProductTitle, "Products");
	}

	@Test(dataProvider = "getData")
	public void verifyUserCanAddMultipleItemsInCartAndCheckTotalOfAllCartItemsPriceAndMakeOrder(String name,
			String gender, String country) throws InterruptedException {

		// filling form
		formPage.setNameField(name);
		formPage.setGender(gender);
		formPage.setCountrySelection(country);
		ProductCatalogue productCatalogue = formPage.submitForm();

		// navigated to product catalogue list page
		productCatalogue.addItemsToCartByIndex(0);
		productCatalogue.addItemsToCartByIndex(0);
		CartPage cartPage = productCatalogue.goToCartPage();

		// navigated to cart page
		// Adding and asserting prices
		double totalSum = cartPage.getProductSum();
		double displayedFormattedSum = cartPage.getFormattedTotalAmountDisplayed();
		Assert.assertEquals(totalSum, displayedFormattedSum);

		cartPage.acceptTermsConditions();
		cartPage.submitOrder();
	}

	@DataProvider
	public Object[][] getData() {
		return new Object[][] { { "Deepak jagtap", "male", "Antarctica" }, { "Rohit mughale", "female", "Angola" } };

	}
}
